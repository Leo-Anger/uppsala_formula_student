import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import MemberCard from "@/components/MemberCard";
import { members } from "@/data/members";

export const metadata: Metadata = {
  title: "About",
  description:
    "Meet Uppsala Formula Student and learn about our goals, values, and student team.",
};

const goals = [
  {
    number: "01",
    title: "Learn by building",
    description:
      "Give students practical experience designing, building, and testing a real vehicle.",
  },
  {
    number: "02",
    title: "Take our first car to competition",
    description:
      "Build Uppsala Formula Student's first car and bring it to the starting line in 2027 or 2028.",
  },
  {
    number: "03",
    title: "Pass inspection safely",
    description:
      "Pass technical inspection on the first attempt, with safety always taking priority.",
  },
  {
    number: "04",
    title: "Build knowledge that lasts",
    description:
      "Create a team and a documented knowledge base that can grow across many seasons.",
  },
  {
    number: "05",
    title: "Create lasting partnerships",
    description:
      "Work with companies that want to help develop the engineers of the future.",
  },
];

const values = [
  {
    title: "Safety first",
    description:
      "No deadline is more important than keeping everyone in the team and on the track safe.",
  },
  {
    title: "Learn by doing",
    description:
      "Nobody needs to know everything on day one. Everyone needs to be willing to learn.",
  },
  {
    title: "Share knowledge",
    description:
      "We document what we learn so the next person can continue from a stronger starting point.",
  },
  {
    title: "Keep our promises",
    description:
      "We deliver on commitments to one another and to every organisation that supports us.",
  },
  {
    title: "Work as one team",
    description:
      "No part of the car works in isolation, and nobody should have to solve a problem alone.",
  },
  {
    title: "Everyone is welcome",
    description:
      "We look for commitment and curiosity, not one particular programme or background.",
  },
];

const teams = [
  {
    key: "management",
    label: "Management",
    description: "Direction, finance, partnerships, communication, and team operations.",
  },
  {
    key: "chassis",
    label: "Chassis",
    description: "Structure, suspension, steering, brakes, wheels, and the driver environment.",
  },
  {
    key: "drivetrain",
    label: "Drivetrain",
    description: "Motors, transmission, cooling, control, simulation, and vehicle performance.",
  },
  {
    key: "electrical",
    label: "Electrical",
    description: "Accumulator, safety systems, low voltage, sensors, and data acquisition.",
  },
] as const;

export default function AboutPage() {
  return (
    <>
      <div className="pointer-events-none fixed inset-0 -z-10 overflow-hidden">
        <div className="racing-background absolute -inset-[20%] rotate-[-8deg] scale-125" />
      </div>

      <main className="overflow-x-clip text-zinc-950 dark:text-white">
        <section className="mx-auto w-full max-w-[1600px] px-4 pb-16 pt-10 md:px-10 md:pb-24 md:pt-16">
          <div className="relative min-h-[540px] overflow-hidden rounded-3xl shadow-2xl md:min-h-[680px]">
            <Image
              src="/images/Angstrom-2020.jpg"
              alt="The Ångström Laboratory at Uppsala University"
              fill
              priority
              sizes="(max-width: 1600px) 100vw, 1600px"
              className="object-cover"
            />

            <div className="absolute inset-0 bg-black/50" />
            <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/45 to-black/10" />
            <div className="absolute inset-x-0 bottom-0 h-2/3 bg-gradient-to-t from-black/75 to-transparent md:hidden" />

            <div className="absolute inset-0 flex items-end p-7 sm:p-10 md:p-14 lg:p-16">
              <div className="relative max-w-4xl border-l-4 border-blue-500 pl-6 md:pl-9">
                <p className="mb-5 text-sm font-black uppercase tracking-[0.24em] text-blue-300">
                  About UFS
                </p>
                <h1 className="text-5xl font-black italic leading-[0.9] tracking-[-0.05em] text-white sm:text-6xl md:text-8xl">
                  Built by students.
                  <br />
                  Built to last.
                </h1>
                <p className="mt-7 max-w-3xl text-base font-medium leading-7 text-zinc-100 sm:text-lg md:text-xl md:leading-8">
                  Uppsala Formula Student is a student-led team designing and
                  building Uppsala&apos;s first Formula Student car. Students from
                  different fields combine engineering, business, and teamwork
                  to turn a blank page into a competition-ready vehicle.
                </p>
              </div>
            </div>
          </div>
        </section>

        <section className="mx-auto w-full max-w-[1400px] px-4 py-16 md:px-10 md:py-24">
          <div className="grid overflow-hidden rounded-3xl border border-zinc-200 bg-white/80 shadow-xl backdrop-blur-xl dark:border-zinc-800 dark:bg-zinc-950/80 lg:grid-cols-[0.9fr_1.1fr]">
            <div className="p-8 md:p-14">
              <p className="text-sm font-black uppercase tracking-[0.24em] text-blue-600 dark:text-blue-400">
                Formula Student
              </p>
              <h2 className="mt-5 text-4xl font-black leading-[0.95] tracking-tight md:text-6xl">
                A complete engineering challenge.
              </h2>
            </div>

            <div className="bg-[#0B1F33] p-8 text-white md:p-14">
              <p className="text-lg leading-8 text-zinc-200 md:text-xl">
                Formula Student challenges university teams to develop a
                single-seat race car as a real engineering project. The work
                reaches far beyond the car itself: the team must plan, fund,
                document, manufacture, test, and present the entire project.
              </p>
              <p className="mt-6 text-lg leading-8 text-zinc-200 md:text-xl">
                For UFS, the first season is also about building the organisation
                and knowledge that future teams will inherit.
              </p>

              <dl className="mt-10 grid gap-6 border-t border-white/20 pt-8 sm:grid-cols-3">
                <div>
                  <dt className="text-3xl font-black">01</dt>
                  <dd className="mt-1 text-sm text-blue-200">First car</dd>
                </div>
                <div>
                  <dt className="text-3xl font-black">04</dt>
                  <dd className="mt-1 text-sm text-blue-200">Core teams</dd>
                </div>
                <div>
                  <dt className="text-3xl font-black">2027/28</dt>
                  <dd className="mt-1 text-sm text-blue-200">Competition target</dd>
                </div>
              </dl>
            </div>
          </div>
        </section>

        <section className="mx-auto w-full max-w-[1400px] px-4 py-16 md:px-10 md:py-24">
          <div className="mb-12 max-w-3xl">
            <p className="text-sm font-black uppercase tracking-[0.24em] text-blue-600 dark:text-blue-400">
              Our goals
            </p>
            <h2 className="mt-4 text-4xl font-black tracking-tight md:text-6xl">
              The first car is only the beginning.
            </h2>
          </div>

          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-6">
            {goals.map((goal, index) => (
              <article
                key={goal.number}
                className={`group rounded-3xl border border-zinc-200 bg-white/80 p-7 backdrop-blur-xl transition duration-300 hover:-translate-y-1 hover:border-blue-500 hover:shadow-xl dark:border-zinc-800 dark:bg-zinc-950/80 ${
                  index < 3 ? "lg:col-span-2" : "lg:col-span-3"
                }`}
              >
                <div className="flex items-center gap-4">
                  <span className="font-mono text-sm font-black text-blue-600 dark:text-blue-400">
                    {goal.number}
                  </span>
                  <div className="h-px flex-1 bg-zinc-200 transition group-hover:bg-blue-500 dark:bg-zinc-800" />
                </div>
                <h3 className="mt-12 text-2xl font-black tracking-tight">
                  {goal.title}
                </h3>
                <p className="mt-4 leading-7 text-zinc-600 dark:text-zinc-400">
                  {goal.description}
                </p>
              </article>
            ))}
          </div>
        </section>

        <section className="mx-auto w-full max-w-[1400px] px-4 py-16 md:px-10 md:py-24">
          <div className="relative overflow-hidden rounded-3xl bg-zinc-950 px-7 py-14 text-white shadow-2xl sm:px-10 md:px-14 md:py-20">
            <div aria-hidden="true" className="absolute -right-8 -top-20 text-[13rem] font-black italic leading-none text-white/[0.035] md:text-[20rem]">
              UFS
            </div>
            <div className="relative">
              <p className="text-sm font-black uppercase tracking-[0.24em] text-blue-400">
                Our values
              </p>
              <h2 className="mt-4 max-w-3xl text-4xl font-black tracking-tight md:text-6xl">
                How we build matters as much as what we build.
              </h2>

              <div className="mt-12 grid gap-px overflow-hidden rounded-2xl border border-white/10 bg-white/10 md:grid-cols-2 lg:grid-cols-3">
                {values.map((value, index) => (
                  <article key={value.title} className="bg-zinc-950 p-7 md:p-8">
                    <p className="font-mono text-xs font-black text-blue-400">
                      {String(index + 1).padStart(2, "0")}
                    </p>
                    <h3 className="mt-8 text-2xl font-black">{value.title}</h3>
                    <p className="mt-4 leading-7 text-zinc-400">
                      {value.description}
                    </p>
                  </article>
                ))}
              </div>
            </div>
          </div>
        </section>

        <section className="mx-auto w-full max-w-[1400px] px-4 py-16 md:px-10 md:py-24">
          <div className="mb-14 flex flex-col justify-between gap-6 lg:flex-row lg:items-end">
            <div>
              <p className="text-sm font-black uppercase tracking-[0.24em] text-blue-600 dark:text-blue-400">
                The people behind UFS
              </p>
              <h2 className="mt-4 text-4xl font-black tracking-tight md:text-6xl">
                Meet the team.
              </h2>
            </div>
            <p className="max-w-xl leading-7 text-zinc-600 dark:text-zinc-400">
              Four disciplines, one car. Every team works across boundaries so
              decisions remain safe, practical, and connected.
            </p>
          </div>

          {teams.map((team) => {
            const teamMembers = members.filter((member) =>
              member.teams.includes(team.key),
            );

            return (
              <section key={team.key} id={team.key} className="scroll-mt-28 py-10">
                <div className="mb-8 border-b border-zinc-200 pb-6 dark:border-zinc-800 md:flex md:items-end md:justify-between md:gap-8">
                  <h3 className="text-3xl font-black italic tracking-tight md:text-4xl">
                    {team.label}
                  </h3>
                  <p className="mt-3 max-w-xl text-zinc-600 dark:text-zinc-400 md:mt-0 md:text-right">
                    {team.description}
                  </p>
                </div>

                {teamMembers.length > 0 ? (
                  <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                    {teamMembers.map((member) => (
                      <MemberCard key={`${team.key}-${member.name}`} member={member} />
                    ))}
                  </div>
                ) : (
                  <div className="rounded-3xl border border-dashed border-zinc-300 bg-white/60 p-8 text-zinc-600 dark:border-zinc-700 dark:bg-zinc-950/60 dark:text-zinc-400">
                    This team is currently recruiting its founding members.
                  </div>
                )}
              </section>
            );
          })}
        </section>

        <section className="mx-auto w-full max-w-[1400px] px-4 pb-10 pt-16 md:px-10 md:pb-16 md:pt-24">
          <div className="rounded-3xl bg-blue-600 px-7 py-16 text-center text-white shadow-2xl sm:px-10 md:py-24">
            <p className="text-sm font-black uppercase tracking-[0.24em] text-blue-100">
              Build the first chapter
            </p>
            <h2 className="mx-auto mt-5 max-w-4xl text-4xl font-black leading-tight tracking-tight md:text-6xl">
              Your work could become part of UFS01.
            </h2>
            <p className="mx-auto mt-6 max-w-2xl text-lg leading-8 text-blue-100">
              We are recruiting across management, chassis, drivetrain, and
              electrical. Experience helps; commitment matters more.
            </p>
            <Link
              href="/join"
              className="mt-9 inline-flex rounded-lg bg-white px-7 py-3.5 font-black text-blue-700 transition hover:bg-blue-50 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-white"
            >
              Explore open roles →
            </Link>
          </div>
        </section>
      </main>
    </>
  );
}
